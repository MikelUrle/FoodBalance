package com.mikel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodBalanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
