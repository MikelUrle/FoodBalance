package com.mikel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodBalanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodBalanceApplication.class, args);
	}

}
